# 2D Animation Director

面向故事型二维动画的 Codex Plugin。它把剧本、角色、场景、道具和视听参考编译为可制作、可检查、可生成的导演方案，而不是只输出抽象的“电影感”描述。

## 能做什么

- 完整节拍图、镜头总表和逐镜导演卡
- 景别、机位、构图、轴线、人物位置与镜头运动
- 视线、呼吸、表情、身体重心和潜文本表演
- 动作起势、发力、接触、惯性、余震与恢复
- 光色、声音、剪辑点、视觉隐喻与连续性账本
- Seedance、Higgsfield 等平台的逐生成单元视频提示词
- 分镜、动作、情绪戏和生成结果的质量诊断

## 安装为 Codex Plugin

克隆或下载仓库后，在终端执行：

```powershell
codex plugin marketplace add "<仓库根目录>"
codex plugin add 2d-animation-director@2d-animation-director
```

随后重启 Codex或新建任务，并输入：

```text
使用 $2d-animation-director，把我的剧本制作成完整二维动画分镜和逐镜视频提示词。
```

## 只安装 Skill

复制下面的文件夹：

```text
plugins/2d-animation-director/skills/2d-animation-director
```

到用户的 `.agents/skills/2d-animation-director`。部分 Codex Desktop 环境也使用 `.codex/skills/2d-animation-director`。

## 仓库结构

```text
.agents/plugins/marketplace.json
plugins/2d-animation-director/
├─ .codex-plugin/plugin.json
└─ skills/2d-animation-director/
   ├─ SKILL.md
   ├─ agents/openai.yaml
   └─ references/
```

完整中文说明见 [INSTALL.zh-CN.md](INSTALL.zh-CN.md)。

## 内容边界

本仓库只包含原创工作流、导演规则和交付模板，不包含用于研究的动画原片、抽帧、PDF、DOCX、字幕或其他第三方素材。

当前版本：`1.0.0`
