# 2D 动画导演安装说明

这个压缩包是可分发的本地 Codex Plugin，内含 `$2d-animation-director` Skill。它不包含原始影片、PDF、DOCX、截图或个人素材。

## 方式一：作为 Plugin 安装（推荐）

1. 完整解压本包，保留 `.agents`、`plugins` 和其中的目录结构。
2. 打开终端，将下面的 `<解压目录>` 替换成本包解压后的绝对路径：

   ```powershell
   codex plugin marketplace add "<解压目录>"
   codex plugin add 2d-animation-director@2d-animation-director
   ```

3. 重启 Codex 或新建任务。
4. 输入 `$2d-animation-director` 检查是否出现在 Skill 选择器中。

示例调用：

```text
使用 $2d-animation-director，把我的剧本和角色、场景、道具素材制作成完整二维动画分镜，并输出逐生成单元视频提示词。
```

## 方式二：只复制 Skill

如果不需要 Plugin 市场功能，可复制：

```text
plugins/2d-animation-director/skills/2d-animation-director
```

到目标电脑的用户 Skill 目录：

```text
Windows: C:\Users\<用户名>\.agents\skills\2d-animation-director
macOS/Linux: ~/.agents/skills/2d-animation-director
```

部分 Codex Desktop 安装使用：

```text
Windows: C:\Users\<用户名>\.codex\skills\2d-animation-director
macOS/Linux: ~/.codex/skills/2d-animation-director
```

复制后重启 Codex。如果 Skill 没有出现，先检查是否形成了 `2d-animation-director/2d-animation-director/SKILL.md` 这样的双层嵌套；正确位置应直接包含 `SKILL.md`、`agents` 和 `references`。

## 给其他智能体

- 支持 Open Agent Skills 标准：复制完整 `2d-animation-director` Skill 文件夹，并配置智能体扫描该目录。
- 不支持 Skills：把 `SKILL.md` 作为工作流指令加载，同时让智能体能按相对路径读取 `references`。
- 团队项目：把 Skill 放入仓库根目录的 `.agents/skills/2d-animation-director` 并提交版本控制。

不要同时安装同名的独立 Skill 和 Plugin 版，否则选择器里可能出现两个同名条目。

## 更新

替换完整 Plugin 目录后重新执行：

```powershell
codex plugin add 2d-animation-director@2d-animation-director
```

之后新建任务，以确保智能体加载最新版本。
